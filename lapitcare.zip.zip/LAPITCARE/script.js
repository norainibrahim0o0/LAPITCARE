/* =========================================================
   LAPITCARE
   VANILLA JAVASCRIPT VERSION
========================================================= */


/* =========================================================
   DEMO USERS
========================================================= */

const USERS = [
    {
        id: "U001",
        name: "Arvien Mayad",
        email: "arvien@email.com",
        password: "patient123",
        role: "patient",
        active: true
    },

    {
        id: "U002",
        name: "Mekaila Adiong",
        email: "mekaila@bhc.gov.ph",
        password: "staff123",
        role: "staff",
        active: true
    },

    {
        id: "U003",
        name: "Administrator",
        email: "admin@pagadiancity.gov.ph",
        password: "admin123",
        role: "admin",
        active: true
    }
];


/* =========================================================
   FACILITIES
========================================================= */

const FACILITIES = [

    {
        id: "F001",
        name: "BHC Dao",
        type: "Barangay Health Center",
        barangay: "Dao",
        lat: 7.8296,
        lng: 123.4360,
        operationalStatus: "Open",
        emergency: false,
        queueCount: 8,
        estimatedWaitMinutes: 25,
        address: "Dao, Pagadian City",
        phone: "0912-345-6789",
        hours: "8:00 AM - 5:00 PM",
        specialties: [
            "General Consultation",
            "Maternal Care"
        ]
    },

    {
        id: "F002",
        name: "Pagadian City Health Office",
        type: "City Health Office",
        barangay: "Poblacion",
        lat: 7.8258,
        lng: 123.4388,
        operationalStatus: "Open",
        emergency: false,
        queueCount: 12,
        estimatedWaitMinutes: 35,
        address: "City Health Office, Pagadian City",
        phone: "0917-222-3344",
        hours: "8:00 AM - 5:00 PM",
        specialties: [
            "General Consultation",
            "Vaccination",
            "Laboratory"
        ]
    },

    {
        id: "F003",
        name: "RHU Lourdes Norte",
        type: "Rural Health Unit",
        barangay: "Lourdes Norte",
        lat: 7.8401,
        lng: 123.4302,
        operationalStatus: "Limited",
        emergency: false,
        queueCount: 18,
        estimatedWaitMinutes: 55,
        address: "Lourdes Norte, Pagadian City",
        phone: "0918-333-4455",
        hours: "8:00 AM - 4:00 PM",
        specialties: [
            "General Consultation",
            "Prenatal Care"
        ]
    },

    {
        id: "F004",
        name: "Pagadian City Medical Center",
        type: "District Hospital",
        barangay: "San Pedro",
        lat: 7.8185,
        lng: 123.4305,
        operationalStatus: "Open",
        emergency: false,
        queueCount: 6,
        estimatedWaitMinutes: 20,
        address: "San Pedro, Pagadian City",
        phone: "0920-444-5566",
        hours: "24 Hours",
        specialties: [
            "Emergency Care",
            "Laboratory",
            "General Consultation"
        ]
    },

    {
        id: "F005",
        name: "BHC Tuburan",
        type: "Barangay Health Center",
        barangay: "Tuburan",
        lat: 7.8172,
        lng: 123.4471,
        operationalStatus: "Closed",
        emergency: false,
        queueCount: 0,
        estimatedWaitMinutes: 0,
        address: "Tuburan, Pagadian City",
        phone: "0921-555-6677",
        hours: "8:00 AM - 5:00 PM",
        specialties: [
            "General Consultation"
        ]
    },

    {
        id: "F006",
        name: "BHC San Pedro",
        type: "Barangay Health Center",
        barangay: "San Pedro",
        lat: 7.8150,
        lng: 123.4245,
        operationalStatus: "Open",
        emergency: false,
        queueCount: 4,
        estimatedWaitMinutes: 15,
        address: "San Pedro, Pagadian City",
        phone: "0922-666-7788",
        hours: "8:00 AM - 5:00 PM",
        specialties: [
            "General Consultation",
            "Child Care"
        ]
    }

];


/* =========================================================
   BARANGAYS
========================================================= */

const BARANGAYS = [
    "Dao",
    "Tuburan",
    "Lourdes Norte",
    "Lourdes Sur",
    "Poblacion",
    "San Pedro",
    "Baloyboan",
    "Bandera",
    "Bantal",
    "Datagan",
    "Dumagoc",
    "Kagawasan",
    "Lumbia",
    "Muricay",
    "Napolan",
    "Olutanga",
    "San Francisco",
    "Santa Lucia",
    "Santiago",
    "Tawagan Norte",
    "Tawagan Sur",
    "Tiguma",
    "Upper Sibul",
    "White Beach"
];


/* =========================================================
   APPLICATION STATE
========================================================= */

let currentUser = null;
let currentPage = "dashboard";
let selectedFacilityId = null;
let registrationRole = "patient";
let map = null;
let markers = {};


/* =========================================================
   PAGE TITLES
========================================================= */

const PAGE_TITLES = {

    dashboard: "Resource Availability Dashboard",

    facilities: "Facility Directory",

    beds: "Bed Availability",

    equipment: "Equipment Availability",

    services: "Service Availability",

    "book-appointment": "Book an Appointment",

    "my-appointments": "My Appointments",

    notifications: "Notifications & Reminders",

    "staff-dashboard": "Staff Dashboard",

    "resource-history": "Resource Update History",

    reports: "Reports & Analytics",

    feedback: "Feedback System",

    admin: "Admin Management",

    "activity-logs": "Activity Logs",

    profile: "My Profile"

};


/* =========================================================
   NAVIGATION
========================================================= */

const NAVIGATION = [

    {
        title: "Overview",
        items: [
            {
                id: "dashboard",
                label: "Dashboard",
                icon: "⬛",
                roles: ["patient", "staff", "admin"]
            }
        ]
    },

    {
        title: "Resources",
        items: [
            {
                id: "facilities",
                label: "Facility Directory",
                icon: "🏥",
                roles: ["patient", "staff", "admin"]
            },

            {
                id: "beds",
                label: "Bed Availability",
                icon: "🛏",
                roles: ["patient", "staff", "admin"]
            },

            {
                id: "equipment",
                label: "Equipment",
                icon: "🔬",
                roles: ["patient", "staff", "admin"]
            },

            {
                id: "services",
                label: "Services",
                icon: "🩺",
                roles: ["patient", "staff", "admin"]
            }
        ]
    },

    {
        title: "Appointments",
        items: [
            {
                id: "book-appointment",
                label: "Book Appointment",
                icon: "📅",
                roles: ["patient", "staff", "admin"]
            },

            {
                id: "my-appointments",
                label: "My Appointments",
                icon: "📋",
                roles: ["patient", "staff", "admin"]
            }
        ]
    },

    {
        title: "Account",
        items: [
            {
                id: "profile",
                label: "My Profile",
                icon: "👤",
                roles: ["patient", "staff", "admin"]
            },

            {
                id: "notifications",
                label: "Notifications",
                icon: "🔔",
                roles: ["patient", "staff", "admin"]
            },

            {
                id: "feedback",
                label: "Feedback",
                icon: "💬",
                roles: ["patient", "staff", "admin"]
            }
        ]
    },

    {
        title: "Staff Tools",
        items: [
            {
                id: "staff-dashboard",
                label: "Health Worker Dashboard",
                icon: "🗂",
                roles: ["staff", "admin"]
            },

            {
                id: "resource-history",
                label: "Resource History",
                icon: "📜",
                roles: ["staff", "admin"]
            },

            {
                id: "reports",
                label: "Reports & Analytics",
                icon: "📊",
                roles: ["staff", "admin"]
            }
        ]
    },

    {
        title: "Administration",
        items: [
            {
                id: "admin",
                label: "Admin Management",
                icon: "⚙️",
                roles: ["admin"]
            },

            {
                id: "activity-logs",
                label: "Activity Logs",
                icon: "📝",
                roles: ["admin"]
            }
        ]
    }

];


/* =========================================================
   LOGIN
========================================================= */

document.addEventListener("DOMContentLoaded", function () {

    initializeRegistrationData();

    document
        .getElementById("loginForm")
        .addEventListener("submit", handleLogin);

    document
        .getElementById("registrationForm")
        .addEventListener("submit", handleRegistration);

});


function handleLogin(event) {

    event.preventDefault();

    const email =
        document.getElementById("loginEmail").value.trim();

    const password =
        document.getElementById("loginPassword").value;

    const error =
        document.getElementById("loginError");


    const user = USERS.find(
        u =>
            u.email === email &&
            u.password === password &&
            u.active
    );


    if (!user) {

        error.textContent =
            "Invalid email or password. Please try again.";

        error.classList.remove("hidden");

        return;
    }


    error.classList.add("hidden");

    currentUser = user;

    showApplication();

}


/* =========================================================
   DEMO LOGIN
========================================================= */

function useDemo(role) {

    const user = USERS.find(
        u => u.role === role
    );

    if (!user) return;

    document.getElementById("loginEmail").value =
        user.email;

    document.getElementById("loginPassword").value =
        user.password;

}


/* =========================================================
   SHOW APPLICATION
========================================================= */

function showApplication() {

    document
        .getElementById("loginPage")
        .classList.add("hidden");

    document
        .getElementById("app")
        .classList.remove("hidden");


    updateUserInterface();

    buildSidebar();

    navigate("dashboard");

}


/* =========================================================
   UPDATE USER UI
========================================================= */

function updateUserInterface() {

    const firstLetter =
        currentUser.name.charAt(0).toUpperCase();


    document.getElementById("sidebarAvatar")
        .textContent = firstLetter;

    document.getElementById("headerAvatar")
        .textContent = firstLetter;

    document.getElementById("sidebarUserName")
        .textContent = currentUser.name;

    document.getElementById("headerUserName")
        .textContent = currentUser.name;


    const roleNames = {

        patient: "Patient",

        staff: "Health Worker",

        admin: "Administrator"

    };


    const roleElement =
        document.getElementById("sidebarUserRole");


    roleElement.textContent =
        roleNames[currentUser.role];


    if (currentUser.role === "staff") {

        roleElement.style.background =
            "#10b981";

    }

    else if (currentUser.role === "admin") {

        roleElement.style.background =
            "#a855f7";

    }

    else {

        roleElement.style.background =
            "#0ea5e9";

    }

}


/* =========================================================
   SIDEBAR
========================================================= */

function buildSidebar() {

    const container =
        document.getElementById("sidebarNavigation");

    container.innerHTML = "";


    NAVIGATION.forEach(section => {

        const visibleItems =
            section.items.filter(
                item =>
                    item.roles.includes(
                        currentUser.role
                    )
            );


        if (visibleItems.length === 0) return;


        const sectionElement =
            document.createElement("div");

        sectionElement.className =
            "nav-section";


        sectionElement.innerHTML = `
            <div class="nav-section-title">
                ${section.title}
            </div>
        `;


        visibleItems.forEach(item => {

            const button =
                document.createElement("button");

            button.className =
                "nav-item";

            button.dataset.page =
                item.id;


            button.innerHTML = `

                <span class="nav-icon">
                    ${item.icon}
                </span>

                <span class="nav-label">
                    ${item.label}
                </span>

                ${
                    item.id === "notifications"
                    ? `
                        <span
                            class="nav-badge"
                            id="sidebarNotificationCount"
                        >
                            3
                        </span>
                    `
                    : ""
                }

            `;


            button.addEventListener(
                "click",
                () => {

                    navigate(item.id);

                    closeSidebar();

                }
            );


            sectionElement.appendChild(button);

        });


        container.appendChild(sectionElement);

    });

}


/* =========================================================
   NAVIGATE
========================================================= */

function navigate(page) {

    currentPage = page;


    document.getElementById("pageTitle")
        .textContent =
        PAGE_TITLES[page] || page;


    document.querySelectorAll(".nav-item")
        .forEach(item => {

            item.classList.toggle(
                "active",
                item.dataset.page === page
            );

        });


    renderPage(page);

}


/* =========================================================
   PAGE RENDERER
========================================================= */

function renderPage(page) {

    const content =
        document.getElementById("pageContent");


    if (page === "dashboard") {

        renderDashboard();

    }

    else if (page === "facilities") {

        renderFacilities();

    }

    else if (page === "beds") {

        renderBeds();

    }

    else if (page === "equipment") {

        renderEquipment();

    }

    else if (page === "services") {

        renderServices();

    }

    else if (page === "book-appointment") {

        renderBookAppointment();

    }

    else if (page === "my-appointments") {

        renderMyAppointments();

    }

    else if (page === "notifications") {

        renderNotifications();

    }

    else if (page === "profile") {

        renderProfile();

    }

    else {

        content.innerHTML = `

            <div class="content-card">

                <div class="content-card-header">

                    <div class="content-card-title">
                        ${PAGE_TITLES[page]}
                    </div>

                </div>

                <div style="padding:30px;color:#64748b;font-size:13px;">
                    This module is available in the LapitCARE prototype.
                </div>

            </div>

        `;

    }

}


/* =========================================================
   DASHBOARD
========================================================= */

function renderDashboard() {

    const content =
        document.getElementById("pageContent");


    const openFacilities =
        FACILITIES.filter(
            f => f.operationalStatus === "Open"
        ).length;


    const limitedFacilities =
        FACILITIES.filter(
            f => f.operationalStatus === "Limited"
        ).length;


    content.innerHTML = `

        <h2 class="page-heading">
            Resource Availability Dashboard
        </h2>

        <p class="page-subheading">
            Current public health facility resources in Pagadian City.
        </p>


        <div class="dashboard-grid">

            <div class="stat-card">

                <div class="stat-label">
                    Health Facilities
                </div>

                <div class="stat-number">
                    ${FACILITIES.length}
                </div>

                <div class="stat-description">
                    Registered facilities
                </div>

            </div>


            <div class="stat-card">

                <div class="stat-label">
                    Currently Open
                </div>

                <div class="stat-number">
                    ${openFacilities}
                </div>

                <div class="stat-description">
                    Facilities operating normally
                </div>

            </div>


            <div class="stat-card">

                <div class="stat-label">
                    Limited
                </div>

                <div class="stat-number">
                    ${limitedFacilities}
                </div>

                <div class="stat-description">
                    Facilities with limited operations
                </div>

            </div>


            <div class="stat-card">

                <div class="stat-label">
                    Queue
                </div>

                <div class="stat-number">
                    ${getTotalQueue()}
                </div>

                <div class="stat-description">
                    Estimated patients in queue
                </div>

            </div>

        </div>


        <div class="content-card">

            <div class="content-card-header">

                <div class="content-card-title">
                    Facility Map
                </div>

            </div>

            <div class="map-container" id="dashboardMap"></div>

        </div>

    `;


    initializeMap("dashboardMap");

}


/* =========================================================
   TOTAL QUEUE
========================================================= */

function getTotalQueue() {

    return FACILITIES.reduce(
        (total, facility) =>
            total + facility.queueCount,
        0
    );

}


/* =========================================================
   FACILITY DIRECTORY
========================================================= */

function renderFacilities() {

    const content =
        document.getElementById("pageContent");


    content.innerHTML = `

        <h2 class="page-heading">
            Facility Directory
        </h2>

        <p class="page-subheading">
            Browse public health facilities and view their current status.
        </p>


        <div class="map-layout">

            <div class="facility-list">

                <div class="facility-list-header">
                    ${FACILITIES.length} Health Facilities
                </div>

                <div id="facilityCards"></div>

            </div>


            <div
                class="map-container"
                id="facilityMap"
            ></div>

        </div>

    `;


    const list =
        document.getElementById("facilityCards");


    FACILITIES.forEach(facility => {

        const card =
            document.createElement("div");

        card.className =
            "facility-card";

        card.dataset.id =
            facility.id;


        card.innerHTML = `

            <div class="facility-name">
                ${facility.name}
            </div>

            <div class="facility-type">
                ${facility.type} · ${facility.barangay}
            </div>

            <br>

            ${createStatusBadge(
                facility.emergency
                    ? "Emergency"
                    : facility.operationalStatus,
                true
            )}

        `;


        card.addEventListener(
            "click",
            () => selectFacility(facility.id)
        );


        list.appendChild(card);

    });


    initializeMap("facilityMap");

}


/* =========================================================
   MAP
========================================================= */

function initializeMap(containerId) {

    if (map) {

        map.remove();

        map = null;

    }


    map = L.map(containerId, {

        center: [
            7.8279,
            123.4366
        ],

        zoom: 13,

        zoomControl: true,

        scrollWheelZoom: true

    });


    L.tileLayer(
        "https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png",
        {

            attribution:
                '© <a href="https://www.openstreetmap.org/copyright">OpenStreetMap</a>',

            maxZoom: 19

        }
    ).addTo(map);


    markers = {};


    FACILITIES.forEach(facility => {

        if (
            !facility.lat ||
            !facility.lng
        ) return;


        const marker =
            L.marker(
                [
                    facility.lat,
                    facility.lng
                ],
                {
                    icon:
                        makeFacilityIcon(
                            getMarkerColor(facility),
                            getTypeAbbreviation(facility.type)
                        )
                }
            )
            .addTo(map)
            .bindPopup(
                buildPopup(facility),
                {
                    maxWidth: 270
                }
            );


        marker.on(
            "click",
            () => selectFacility(facility.id)
        );


        markers[facility.id] =
            marker;

    });

}


/* =========================================================
   FACILITY ICON
========================================================= */

function makeFacilityIcon(color, label) {

    const svg = `

        <svg
            xmlns="http://www.w3.org/2000/svg"
            viewBox="0 0 40 52"
            width="40"
            height="52"
        >

            <path
                d="
                    M20 2
                    C12.27 2 6 8.27 6 16
                    C6 27 20 50 20 50
                    S34 27 34 16
                    C34 8.27 27.73 2 20 2z
                "
                fill="${color.bg}"
                stroke="${color.border}"
                stroke-width="1.5"
            />

            <circle
                cx="20"
                cy="16"
                r="9"
                fill="white"
                opacity=".92"
            />

            <text
                x="20"
                y="20"
                text-anchor="middle"
                font-family="Arial"
                font-size="9"
                font-weight="700"
                fill="${color.border}"
            >
                ${label}
            </text>

        </svg>

    `;


    return L.divIcon({

        className: "",

        html: svg,

        iconSize: [
            40,
            52
        ],

        iconAnchor: [
            20,
            52
        ],

        popupAnchor: [
            0,
            -54
        ]

    });

}


/* =========================================================
   MAP COLORS
========================================================= */

function getMarkerColor(facility) {

    if (facility.emergency) {

        return {
            bg: "#dc2626",
            border: "#7f1d1d"
        };

    }


    const colors = {

        Open: {
            bg: "#16a34a",
            border: "#14532d"
        },

        Limited: {
            bg: "#d97706",
            border: "#78350f"
        },

        Closed: {
            bg: "#dc2626",
            border: "#7f1d1d"
        }

    };


    return colors[
        facility.operationalStatus
    ] || colors.Open;

}


/* =========================================================
   TYPE ABBREVIATIONS
========================================================= */

function getTypeAbbreviation(type) {

    const abbreviations = {

        "Barangay Health Center": "BHC",

        "City Health Office": "CHO",

        "Rural Health Unit": "RHU",

        "District Hospital": "DH",

        "Lying-in Clinic": "LIC"

    };


    return abbreviations[type] || "HC";

}


/* =========================================================
   POPUP
========================================================= */

function buildPopup(facility) {

    const status =
        facility.emergency
            ? "Emergency"
            : facility.operationalStatus;


    const queue =
        facility.operationalStatus !== "Closed" &&
        facility.queueCount > 0

            ? `
                <div style="
                    font-size:11px;
                    color:#475569;
                    margin-bottom:5px;
                ">
                    🔢 ${facility.queueCount}
                    in queue ·
                    ~${facility.estimatedWaitMinutes}
                    min wait
                </div>
            `

            : "";


    const specialties =
        facility.specialties
            .map(
                specialty => `
                    <span style="
                        background:#eff6ff;
                        color:#1d4ed8;
                        font-size:10px;
                        padding:2px 6px;
                        border-radius:999px;
                        border:1px solid #bfdbfe;
                    ">
                        ${specialty}
                    </span>
                `
            )
            .join(" ");


    return `

        <div style="
            font-family:Inter,sans-serif;
            min-width:230px;
        ">

            <div style="
                background:${getMarkerColor(facility).bg};
                color:white;
                padding:6px 12px;
                font-size:11px;
                font-weight:700;
            ">

                ${
                    facility.emergency
                        ? "🚨 EMERGENCY"
                        : status.toUpperCase()
                }

            </div>


            <div style="padding:12px;">

                <div style="
                    font-weight:700;
                    font-size:13px;
                    color:#0f172a;
                    margin-bottom:2px;
                ">
                    ${facility.name}
                </div>


                <div style="
                    font-size:11px;
                    color:#64748b;
                    margin-bottom:8px;
                ">
                    ${facility.type}
                    ·
                    ${facility.barangay}
                </div>


                ${queue}


                <div style="
                    font-size:11px;
                    color:#475569;
                    margin-bottom:4px;
                ">
                    📍 ${facility.address}
                </div>


                <div style="
                    font-size:11px;
                    color:#475569;
                    margin-bottom:4px;
                ">
                    📞 ${facility.phone}
                </div>


                <div style="
                    font-size:11px;
                    color:#475569;
                    margin-bottom:8px;
                ">
                    🕐 ${facility.hours}
                </div>


                <div style="
                    display:flex;
                    flex-wrap:wrap;
                    gap:4px;
                ">
                    ${specialties}
                </div>

            </div>

        </div>

    `;

}


/* =========================================================
   SELECT FACILITY
========================================================= */

function selectFacility(id) {

    selectedFacilityId = id;


    const facility =
        FACILITIES.find(
            f => f.id === id
        );


    if (!facility) return;


    document.querySelectorAll(".facility-card")
        .forEach(card => {

            card.classList.toggle(
                "selected",
                card.dataset.id === id
            );

        });


    const marker =
        markers[id];


    if (
        marker &&
        map
    ) {

        map.flyTo(
            [
                facility.lat,
                facility.lng
            ],
            15,
            {
                duration: .8
            }
        );


        marker.setIcon(
            makeFacilityIcon(
                {
                    bg: "#7c3aed",
                    border: "#4c1d95"
                },
                getTypeAbbreviation(
                    facility.type
                )
            )
        );


        marker.openPopup();

    }

}


/* =========================================================
   STATUS BADGE
========================================================= */

function createStatusBadge(
    status,
    dot = false
) {

    const classes = {

        Available: "status-available",

        "Low Stock": "status-low",

        Unavailable: "status-unavailable",

        "Under Maintenance":
            "status-maintenance",

        Limited: "status-limited",

        Pending: "status-pending",

        Approved: "status-approved",

        Completed: "status-completed",

        Cancelled: "status-cancelled",

        Active: "status-active",

        Inactive: "status-inactive",

        Emergency: "status-emergency",

        Reviewed: "status-approved",

        Resolved: "status-resolved"

    };


    const dotColors = {

        Available: "#10b981",

        "Low Stock": "#f59e0b",

        Unavailable: "#ef4444",

        Limited: "#f97316",

        Pending: "#3b82f6",

        Approved: "#10b981",

        Completed: "#94a3b8",

        Cancelled: "#ef4444"

    };


    const className =
        classes[status] ||
        "status-maintenance";


    return `

        <span class="status-badge ${className}">

            ${
                dot
                    ? `
                        <span
                            class="status-dot"
                            style="
                                background:${
                                    dotColors[status]
                                    || "#94a3b8"
                                };
                            "
                        ></span>
                    `
                    : ""
            }

            ${status}

        </span>

    `;

}


/* =========================================================
   BEDS
========================================================= */

function renderBeds() {

    const content =
        document.getElementById("pageContent");


    content.innerHTML = `

        <h2 class="page-heading">
            Bed Availability
        </h2>

        <p class="page-subheading">
            Current bed availability reported by public health facilities.
        </p>


        <div class="content-card">

            <div class="table-wrapper">

                <table class="data-table">

                    <thead>

                        <tr>
                            <th>Facility</th>
                            <th>Total Beds</th>
                            <th>Available</th>
                            <th>Occupied</th>
                            <th>Status</th>
                        </tr>

                    </thead>


                    <tbody>

                        ${FACILITIES.map(
                            (facility, index) => {

                                const total =
                                    10 + index * 4;

                                const available =
                                    Math.max(
                                        0,
                                        6 - index
                                    );

                                const occupied =
                                    total - available;


                                return `

                                    <tr>

                                        <td>
                                            <strong>
                                                ${facility.name}
                                            </strong>
                                        </td>

                                        <td>
                                            ${total}
                                        </td>

                                        <td>
                                            ${available}
                                        </td>

                                        <td>
                                            ${occupied}
                                        </td>

                                        <td>
                                            ${createStatusBadge(
                                                available > 0
                                                    ? "Available"
                                                    : "Unavailable",
                                                true
                                            )}
                                        </td>

                                    </tr>

                                `;

                            }
                        ).join("")}

                    </tbody>

                </table>

            </div>

        </div>

    `;

}


/* =========================================================
   EQUIPMENT
========================================================= */

function renderEquipment() {

    renderSimpleResourcePage(
        "Equipment Availability",
        [
            ["Blood Pressure Monitor", "Available"],
            ["X-Ray Machine", "Available"],
            ["Ultrasound Machine", "Limited"],
            ["ECG Machine", "Available"],
            ["Oxygen Concentrator", "Low Stock"]
        ]
    );

}


/* =========================================================
   SERVICES
========================================================= */

function renderServices() {

    renderSimpleResourcePage(
        "Service Availability",
        [
            ["General Consultation", "Available"],
            ["Maternal Care", "Available"],
            ["Laboratory", "Limited"],
            ["Vaccination", "Available"],
            ["Emergency Care", "Available"]
        ]
    );

}


/* =========================================================
   SIMPLE RESOURCE PAGE
========================================================= */

function renderSimpleResourcePage(
    title,
    resources
) {

    const content =
        document.getElementById("pageContent");


    content.innerHTML = `

        <h2 class="page-heading">
            ${title}
        </h2>

        <p class="page-subheading">
            Current resource information from participating facilities.
        </p>


        <div class="content-card">

            <div class="table-wrapper">

                <table class="data-table">

                    <thead>

                        <tr>
                            <th>Resource / Service</th>
                            <th>Status</th>
                        </tr>

                    </thead>


                    <tbody>

                        ${resources.map(
                            resource => `

                                <tr>

                                    <td>
                                        ${resource[0]}
                                    </td>

                                    <td>
                                        ${createStatusBadge(
                                            resource[1],
                                            true
                                        )}
                                    </td>

                                </tr>

                            `
                        ).join("")}

                    </tbody>

                </table>

            </div>

        </div>

    `;

}


/* =========================================================
   BOOK APPOINTMENT
========================================================= */

function renderBookAppointment() {

    const content =
        document.getElementById("pageContent");


    content.innerHTML = `

        <h2 class="page-heading">
            Book an Appointment
        </h2>

        <p class="page-subheading">
            Select a public health facility and schedule an appointment.
        </p>


        <div class="content-card">

            <div style="padding:20px;max-width:650px;">

                <form id="appointmentForm">

                    <div class="form-group">

                        <label>
                            Health Facility
                        </label>

                        <select id="appointmentFacility">

                            <option value="">
                                Select facility...
                            </option>

                            ${FACILITIES
                                .filter(
                                    f =>
                                        f.operationalStatus !== "Closed"
                                )
                                .map(
                                    f => `
                                        <option value="${f.id}">
                                            ${f.name}
                                        </option>
                                    `
                                )
                                .join("")}

                        </select>

                    </div>


                    <div class="form-group">

                        <label>
                            Service
                        </label>

                        <select id="appointmentService">

                            <option>
                                General Consultation
                            </option>

                            <option>
                                Maternal Care
                            </option>

                            <option>
                                Vaccination
                            </option>

                            <option>
                                Laboratory
                            </option>

                        </select>

                    </div>


                    <div class="two-columns">

                        <div class="form-group">

                            <label>
                                Appointment Date
                            </label>

                            <input
                                type="date"
                                id="appointmentDate"
                                required
                            >

                        </div>


                        <div class="form-group">

                            <label>
                                Preferred Time
                            </label>

                            <select id="appointmentTime">

                                <option>
                                    8:00 AM
                                </option>

                                <option>
                                    9:00 AM
                                </option>

                                <option>
                                    10:00 AM
                                </option>

                                <option>
                                    1:00 PM
                                </option>

                                <option>
                                    2:00 PM
                                </option>

                                <option>
                                    3:00 PM
                                </option>

                            </select>

                        </div>

                    </div>


                    <div
                        id="appointmentMessage"
                        class="hidden"
                    ></div>


                    <button
                        class="primary-button"
                        type="submit"
                    >
                        Confirm Appointment
                    </button>

                </form>

            </div>

        </div>

    `;


    document
        .getElementById("appointmentForm")
        .addEventListener(
            "submit",
            function (event) {

                event.preventDefault();


                const message =
                    document.getElementById(
                        "appointmentMessage"
                    );


                message.className =
                    "notice staff-notice";


                message.textContent =
                    "Appointment submitted successfully. Your appointment is pending confirmation.";

            }
        );

}


/* =========================================================
   MY APPOINTMENTS
========================================================= */

function renderMyAppointments() {

    const content =
        document.getElementById("pageContent");


    content.innerHTML = `

        <h2 class="page-heading">
            My Appointments
        </h2>

        <p class="page-subheading">
            View and manage your scheduled appointments.
        </p>


        <div class="content-card">

            <div class="table-wrapper">

                <table class="data-table">

                    <thead>

                        <tr>
                            <th>Facility</th>
                            <th>Service</th>
                            <th>Date</th>
                            <th>Time</th>
                            <th>Status</th>
                        </tr>

                    </thead>


                    <tbody>

                        <tr>

                            <td>
                                Pagadian City Health Office
                            </td>

                            <td>
                                General Consultation
                            </td>

                            <td>
                                September 18, 2026
                            </td>

                            <td>
                                9:00 AM
                            </td>

                            <td>
                                ${createStatusBadge(
                                    "Approved",
                                    true
                                )}
                            </td>

                        </tr>


                        <tr>

                            <td>
                                BHC Dao
                            </td>

                            <td>
                                Vaccination
                            </td>

                            <td>
                                September 24, 2026
                            </td>

                            <td>
                                10:00 AM
                            </td>

                            <td>
                                ${createStatusBadge(
                                    "Pending",
                                    true
                                )}
                            </td>

                        </tr>

                    </tbody>

                </table>

            </div>

        </div>

    `;

}


/* =========================================================
   NOTIFICATIONS
========================================================= */

function renderNotifications() {

    const content =
        document.getElementById("pageContent");


    content.innerHTML = `

        <h2 class="page-heading">
            Notifications & Reminders
        </h2>

        <p class="page-subheading">
            Important updates regarding facilities and appointments.
        </p>


        <div class="content-card">

            <div style="padding:0;">

                <div style="
                    padding:15px;
                    border-bottom:1px solid #e2e8f0;
                ">

                    <strong style="font-size:12px;">
                        Appointment Reminder
                    </strong>

                    <p style="
                        color:#64748b;
                        font-size:11px;
                    ">
                        Your appointment at Pagadian City Health Office
                        is scheduled for September 18, 2026 at 9:00 AM.
                    </p>

                </div>


                <div style="
                    padding:15px;
                    border-bottom:1px solid #e2e8f0;
                ">

                    <strong style="font-size:12px;">
                        Facility Update
                    </strong>

                    <p style="
                        color:#64748b;
                        font-size:11px;
                    ">
                        RHU Lourdes Norte is currently operating with
                        limited services.
                    </p>

                </div>


                <div style="
                    padding:15px;
                ">

                    <strong style="font-size:12px;">
                        Resource Update
                    </strong>

                    <p style="
                        color:#64748b;
                        font-size:11px;
                    ">
                        New bed availability information has been posted.
                    </p>

                </div>

            </div>

        </div>

    `;

}


/* =========================================================
   PROFILE
========================================================= */

function renderProfile() {

    const content =
        document.getElementById("pageContent");


    content.innerHTML = `

        <h2 class="page-heading">
            My Profile
        </h2>

        <p class="page-subheading">
            Manage your account information.
        </p>


        <div class="content-card">

            <div style="
                padding:20px;
                max-width:600px;
            ">

                <div class="form-group">

                    <label>
                        Full Name
                    </label>

                    <input
                        value="${currentUser.name}"
                        readonly
                    >

                </div>


                <div class="form-group">

                    <label>
                        Email
                    </label>

                    <input
                        value="${currentUser.email}"
                        readonly
                    >

                </div>


                <div class="form-group">

                    <label>
                        Account Role
                    </label>

                    <input
                        value="${getRoleName(currentUser.role)}"
                        readonly
                    >

                </div>

            </div>

        </div>

    `;

}


/* =========================================================
   ROLE NAME
========================================================= */

function getRoleName(role) {

    const roles = {

        patient: "Patient",

        staff: "Health Worker",

        admin: "Administrator"

    };


    return roles[role] || role;

}


/* =========================================================
   REGISTRATION
========================================================= */

function initializeRegistrationData() {

    const barangay =
        document.getElementById(
            "regBarangay"
        );


    BARANGAYS.forEach(
        barangayName => {

            const option =
                document.createElement(
                    "option"
                );

            option.value =
                barangayName;

            option.textContent =
                barangayName;

            barangay.appendChild(
                option
            );

        }
    );


    const facility =
        document.getElementById(
            "regFacility"
        );


    FACILITIES.forEach(
        f => {

            const option =
                document.createElement(
                    "option"
                );

            option.value =
                f.name;

            option.textContent =
                f.name;

            facility.appendChild(
                option
            );

        }
    );

}


/* =========================================================
   SHOW LOGIN
========================================================= */

function showLogin() {

    document
        .getElementById("loginFormContainer")
        .classList.remove("hidden");

    document
        .getElementById("registerContainer")
        .classList.add("hidden");


    document
        .getElementById("signInTab")
        .classList.add("active");

    document
        .getElementById("registerTab")
        .classList.remove("active");

}


/* =========================================================
   SHOW REGISTER
========================================================= */

function showRegister() {

    document
        .getElementById("loginFormContainer")
        .classList.add("hidden");

    document
        .getElementById("registerContainer")
        .classList.remove("hidden");


    document
        .getElementById("signInTab")
        .classList.remove("active");

    document
        .getElementById("registerTab")
        .classList.add("active");


    showRegistrationStep(1);

}


/* =========================================================
   SELECT REGISTRATION ROLE
========================================================= */

function selectRegistrationRole(role) {

    registrationRole = role;


    document
        .querySelectorAll(
            ".registration-role"
        )
        .forEach(button => {

            button.classList.toggle(
                "selected",
                button.dataset.role === role
            );

        });


    const continueButton =
        document.querySelector(
            "#registerStep1 .primary-button"
        );


    const roleNames = {

        patient:
            "Patient / Resident",

        staff:
            "Health Worker",

        admin:
            "Administrator"

    };


    continueButton.textContent =
        `Continue as ${roleNames[role]} →`;


    document
        .getElementById("adminNotice")
        .classList.toggle(
            "hidden",
            role !== "admin"
        );


    document
        .getElementById("staffNotice")
        .classList.toggle(
            "hidden",
            role !== "staff"
        );

}


/* =========================================================
   REGISTRATION FORM
========================================================= */

function goToRegistrationForm() {

    showRegistrationStep(2);

    updateRegistrationFields();

}


/* =========================================================
   UPDATE REGISTRATION FIELDS
========================================================= */

function updateRegistrationFields() {

    const patient =
        document.getElementById(
            "patientFields"
        );

    const staff =
        document.getElementById(
            "staffFields"
        );

    const admin =
        document.getElementById(
            "adminFields"
        );


    patient.classList.toggle(
        "hidden",
        registrationRole !== "patient"
    );

    staff.classList.toggle(
        "hidden",
        registrationRole !== "staff"
    );

    admin.classList.toggle(
        "hidden",
        registrationRole !== "admin"
    );


    const titles = {

        patient:
            "Personal Details",

        staff:
            "Health Worker Information",

        admin:
            "Administrator Registration"

    };


    document.getElementById(
        "registrationTitle"
    ).textContent =
        titles[registrationRole];


    const badge =
        document.getElementById(
            "registrationRoleBadge"
        );


    badge.className =
        "role-badge " +
        registrationRole +
        "-badge";


    const badgeText = {

        patient:
            "👤 Patient / Resident",

        staff:
            "🩺 Health Worker",

        admin:
            "⚙️ Administrator"

    };


    badge.textContent =
        badgeText[registrationRole];

}


/* =========================================================
   REGISTRATION SUBMIT
========================================================= */

function handleRegistration(event) {

    event.preventDefault();


    const error =
        document.getElementById(
            "registrationError"
        );


    error.classList.add("hidden");


    const name =
        document.getElementById(
            "regName"
        ).value.trim();


    const email =
        document.getElementById(
            "regEmail"
        ).value.trim();


    const phone =
        document.getElementById(
            "regPhone"
        ).value.trim();


    const password =
        document.getElementById(
            "regPassword"
        ).value;


    const confirm =
        document.getElementById(
            "regConfirm"
        ).value;


    if (
        !name ||
        !email ||
        !phone ||
        !password
    ) {

        showRegistrationError(
            "Please fill in all required fields."
        );

        return;

    }


    if (password !== confirm) {

        showRegistrationError(
            "Passwords do not match."
        );

        return;

    }


    if (password.length < 8) {

        showRegistrationError(
            "Password must be at least 8 characters."
        );

        return;

    }


    if (
        USERS.some(
            user =>
                user.email === email
        )
    ) {

        showRegistrationError(
            "An account with this email already exists."
        );

        return;

    }


    if (
        registrationRole === "staff" &&
        !document.getElementById(
            "regFacility"
        ).value
    ) {

        showRegistrationError(
            "Please select an assigned facility."
        );

        return;

    }


    if (
        registrationRole === "admin" &&
        document.getElementById(
            "regAdminCode"
        ).value !== "PAGADIAN2025"
    ) {

        showRegistrationError(
            "Invalid administrator registration code."
        );

        return;

    }


    showRegistrationStep(3);


    const roleNames = {

        patient: "Patient / Resident",

        staff: "Health Worker",

        admin: "Administrator"

    };


    let message =
        `Your ${roleNames[registrationRole]} account registration has been submitted. `;


    if (
        registrationRole === "staff"
    ) {

        const facility =
            document.getElementById(
                "regFacility"
            ).value;


        message +=
            `Your account at ${facility} is pending administrator approval.`;

    }

    else if (
        registrationRole === "admin"
    ) {

        message +=
            "Your administrator account has been forwarded for verification.";

    }

    else {

        message +=
            "An administrator will review your registration before activation.";

    }


    document.getElementById(
        "successMessage"
    ).textContent =
        message;

}


/* =========================================================
   REGISTRATION ERROR
========================================================= */

function showRegistrationError(
    message
) {

    const error =
        document.getElementById(
            "registrationError"
        );


    error.textContent =
        message;


    error.classList.remove(
        "hidden"
    );

}


/* =========================================================
   REGISTRATION STEPS
========================================================= */

function showRegistrationStep(step) {

    document
        .getElementById(
            "registerStep1"
        )
        .classList.toggle(
            "hidden",
            step !== 1
        );


    document
        .getElementById(
            "registerStep2"
        )
        .classList.toggle(
            "hidden",
            step !== 2
        );


    document
        .getElementById(
            "registerSuccess"
        )
        .classList.toggle(
            "hidden",
            step !== 3
        );

}


/* =========================================================
   BACK TO ROLE
========================================================= */

function backToRoleSelection() {

    showRegistrationStep(1);

}


/* =========================================================
   BACK TO LOGIN
========================================================= */

function backToLogin() {

    showLogin();

}


/* =========================================================
   LOGOUT
========================================================= */

function logout() {

    currentUser = null;

    currentPage = "dashboard";


    if (map) {

        map.remove();

        map = null;

    }


    document
        .getElementById("app")
        .classList.add("hidden");


    document
        .getElementById("loginPage")
        .classList.remove("hidden");


    document
        .getElementById("loginEmail")
        .value = "";

    document
        .getElementById("loginPassword")
        .value = "";

}


/* =========================================================
   MOBILE SIDEBAR
========================================================= */

function openSidebar() {

    document
        .getElementById("sidebar")
        .classList.add("open");

    document
        .getElementById("sidebarOverlay")
        .classList.remove("hidden");

}


function closeSidebar() {

    document
        .getElementById("sidebar")
        .classList.remove("open");

    document
        .getElementById("sidebarOverlay")
        .classList.add("hidden");

}