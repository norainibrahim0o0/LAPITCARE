document.addEventListener('DOMContentLoaded', () => {
  const form = document.getElementById('loginForm');
  const errorBox = document.getElementById('loginError');

  const demoButtons = document.querySelectorAll('[data-demo]');
  demoButtons.forEach((button) => {
    button.addEventListener('click', () => {
      const role = button.dataset.demo;
      const emailMap = {
        patient: 'arvien@email.com',
        staff: 'mekaila@bhc.gov.ph',
        admin: 'admin@pagadiancity.gov.ph'
      };
      const passwordMap = {
        patient: 'patient123',
        staff: 'staff123',
        admin: 'admin123'
      };

      const emailInput = document.getElementById('loginEmail');
      const passwordInput = document.getElementById('loginPassword');

      if (emailInput) emailInput.value = emailMap[role] || '';
      if (passwordInput) passwordInput.value = passwordMap[role] || '';
      if (errorBox) errorBox.classList.add('hidden');
    });
  });

  if (!form) return;

  form.addEventListener('submit', (event) => {
    event.preventDefault();

    const email = document.getElementById('loginEmail').value.trim();
    const password = document.getElementById('loginPassword').value.trim();
    const user = (window.USERS || []).find(
      (item) => item.email.toLowerCase() === email.toLowerCase() && item.password === password
    );

    if (!user) {
      errorBox.textContent = 'Invalid email or password. Please try again.';
      errorBox.classList.remove('hidden');
      return;
    }

    errorBox.classList.add('hidden');
    localStorage.setItem('lapitcareUser', JSON.stringify(user));
    window.location.href = 'app.html';
  });
});
