document.addEventListener('DOMContentLoaded', () => {
  const form = document.getElementById('registerForm');
  const roleButtons = document.querySelectorAll('.role-option');
  const errorBox = document.getElementById('registerError');

  if (!form) return;

  let selectedRole = 'patient';

  roleButtons.forEach((button) => {
    button.addEventListener('click', () => {
      selectedRole = button.dataset.role || 'patient';
      roleButtons.forEach((item) => item.classList.toggle('selected', item === button));
    });
  });

  form.addEventListener('submit', (event) => {
    event.preventDefault();

    const fullName = document.getElementById('registerFullName').value.trim();
    const email = document.getElementById('registerEmail').value.trim();
    const password = document.getElementById('registerPassword').value.trim();

    if (!fullName || !email || !password) {
      errorBox.textContent = 'Please complete all required fields.';
      errorBox.classList.remove('hidden');
      return;
    }

    const exists = (window.USERS || []).some((user) => user.email.toLowerCase() === email.toLowerCase());
    if (exists) {
      errorBox.textContent = 'This email is already registered.';
      errorBox.classList.remove('hidden');
      return;
    }

    const newUser = {
      id: `U${String((window.USERS || []).length + 1).padStart(3, '0')}`,
      name: fullName,
      email,
      password,
      role: selectedRole,
      active: true
    };

    (window.USERS || []).push(newUser);
    localStorage.setItem('lapitcareUser', JSON.stringify(newUser));
    window.location.href = 'app.html';
  });
});
