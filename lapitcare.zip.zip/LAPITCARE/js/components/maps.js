document.addEventListener('DOMContentLoaded', () => {
  const mapContainer = document.getElementById('mapContainer');
  if (!mapContainer || typeof L === 'undefined') return;

  const map = L.map(mapContainer, { zoomControl: true }).setView([7.8258, 123.4388], 12);
  L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png', {
    attribution: '&copy; OpenStreetMap contributors'
  }).addTo(map);

  const markers = [
    { name: 'BHC Dao', coords: [7.8296, 123.436] },
    { name: 'Pagadian City Health Office', coords: [7.8258, 123.4388] },
    { name: 'RHU Lourdes Norte', coords: [7.8401, 123.4302] }
  ];

  markers.forEach((marker) => {
    L.marker(marker.coords).addTo(map).bindPopup(`<strong>${marker.name}</strong>`);
  });
});
