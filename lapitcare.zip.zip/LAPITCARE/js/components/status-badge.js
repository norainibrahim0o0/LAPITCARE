function statusBadge(label, tone = 'available') {
  return `<span class="status-badge status-${tone}">${label}</span>`;
}
