document.addEventListener('DOMContentLoaded', () => {
  console.log('Facilities page ready');
});
