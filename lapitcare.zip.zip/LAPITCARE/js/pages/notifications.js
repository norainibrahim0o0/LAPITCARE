document.addEventListener('DOMContentLoaded', () => {
  console.log('Notifications page ready');
});
