document.addEventListener('DOMContentLoaded', () => {
  console.log('Beds page ready');
});
