document.addEventListener('DOMContentLoaded', () => {
  console.log('Appointments page ready');
});
