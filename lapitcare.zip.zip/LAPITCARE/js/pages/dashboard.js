document.addEventListener('DOMContentLoaded', () => {
  const activeUser = JSON.parse(localStorage.getItem('lapitcareUser') || 'null');
  if (!activeUser) return;

  const sidebarUser = document.querySelector('.sidebar-user-info > div');
  const sidebarRole = document.querySelector('.sidebar-user-info span');
  const topbarUser = document.querySelector('.topbar-user span');

  if (sidebarUser) sidebarUser.textContent = activeUser.name;
  if (sidebarRole) sidebarRole.textContent = activeUser.role;
  if (topbarUser) topbarUser.textContent = activeUser.name;
});
