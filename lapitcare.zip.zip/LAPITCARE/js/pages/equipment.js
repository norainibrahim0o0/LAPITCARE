document.addEventListener('DOMContentLoaded', () => {
  console.log('Equipment page ready');
});
