window.APP_CONSTANTS = {
  roles: ['patient', 'staff', 'admin'],
  pageTitles: {
    dashboard: 'Resource Availability Dashboard',
    facilities: 'Facility Directory',
    beds: 'Bed Availability',
    equipment: 'Equipment Availability',
    services: 'Service Availability',
    appointments: 'Appointments',
    notifications: 'Notifications & Reminders',
    profile: 'My Profile'
  }
};
