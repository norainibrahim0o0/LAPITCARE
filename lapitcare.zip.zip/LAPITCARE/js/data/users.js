window.USERS = [
  {
    id: 'U001',
    name: 'Arvien Mayad',
    email: 'arvien@email.com',
    password: 'patient123',
    role: 'patient',
    active: true
  },
  {
    id: 'U002',
    name: 'Mekaila Adiong',
    email: 'mekaila@bhc.gov.ph',
    password: 'staff123',
    role: 'staff',
    active: true
  },
  {
    id: 'U003',
    name: 'Administrator',
    email: 'admin@pagadiancity.gov.ph',
    password: 'admin123',
    role: 'admin',
    active: true
  }
];
