window.FACILITIES = [
  {
    id: 'F001',
    name: 'BHC Dao',
    type: 'Barangay Health Center',
    barangay: 'Dao',
    lat: 7.8296,
    lng: 123.436,
    operationalStatus: 'Open',
    queueCount: 8,
    estimatedWaitMinutes: 25,
    specialties: ['General Consultation', 'Maternal Care']
  },
  {
    id: 'F002',
    name: 'Pagadian City Health Office',
    type: 'City Health Office',
    barangay: 'Poblacion',
    lat: 7.8258,
    lng: 123.4388,
    operationalStatus: 'Open',
    queueCount: 12,
    estimatedWaitMinutes: 35,
    specialties: ['General Consultation', 'Vaccination', 'Laboratory']
  },
  {
    id: 'F003',
    name: 'RHU Lourdes Norte',
    type: 'Rural Health Unit',
    barangay: 'Lourdes Norte',
    lat: 7.8401,
    lng: 123.4302,
    operationalStatus: 'Limited',
    queueCount: 18,
    estimatedWaitMinutes: 55,
    specialties: ['General Consultation', 'Prenatal Care']
  }
];
