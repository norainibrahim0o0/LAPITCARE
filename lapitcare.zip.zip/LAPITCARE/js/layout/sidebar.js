document.addEventListener('DOMContentLoaded', () => {
  const sidebar = document.getElementById('sidebar');
  const menuButton = document.getElementById('mobileMenuButton');

  if (menuButton && sidebar) {
    menuButton.addEventListener('click', () => {
      sidebar.classList.toggle('open');
    });
  }

  const navItems = document.querySelectorAll('.nav-item');
  navItems.forEach((item) => {
    item.addEventListener('click', () => {
      navItems.forEach((nav) => nav.classList.toggle('active', nav === item));
      const target = item.dataset.page;
      const viewMap = {
        dashboard: 'dashboardView',
        facilities: 'facilitiesView',
        profile: 'profileView'
      };

      if (target && viewMap[target]) {
        document.querySelectorAll('.view').forEach((view) => {
          view.classList.toggle('hidden', view.id !== viewMap[target]);
        });
      }
    });
  });
});
