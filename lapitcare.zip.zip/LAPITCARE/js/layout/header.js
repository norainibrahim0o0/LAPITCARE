document.addEventListener('DOMContentLoaded', () => {
  const pageTitle = document.getElementById('pageTitle');
  if (!pageTitle) return;

  const titleMap = {
    dashboard: 'Resource Availability Dashboard',
    facilities: 'Facility Directory',
    services: 'Service Availability',
    appointments: 'Appointments',
    notifications: 'Notifications & Reminders',
    profile: 'My Profile'
  };

  const activeNav = document.querySelector('.nav-item.active');
  const activeKey = activeNav ? activeNav.dataset.page : 'dashboard';
  pageTitle.textContent = titleMap[activeKey] || titleMap.dashboard;
});
