document.addEventListener('DOMContentLoaded', () => {
  const pageTitle = document.getElementById('pageTitle');
  if (!pageTitle) return;

  const activeNav = document.querySelector('.nav-item.active');
  const label = activeNav ? activeNav.textContent.trim() : 'Dashboard';
  pageTitle.textContent = label;
});
