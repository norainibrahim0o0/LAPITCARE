document.addEventListener('DOMContentLoaded', () => {
  const currentPage = window.location.pathname.split('/').pop() || 'index.html';

  if (currentPage === 'login.html' || currentPage === 'register.html') {
    const pageRole = currentPage.includes('register') ? 'register' : 'login';
    document.body.dataset.page = pageRole;
  }

  const demoButtons = document.querySelectorAll('[data-demo]');
  demoButtons.forEach((button) => {
    button.addEventListener('click', () => {
      const role = button.dataset.demo;
      const emailMap = {
        patient: 'arvien@email.com',
        staff: 'mekaila@bhc.gov.ph',
        admin: 'admin@pagadiancity.gov.ph'
      };
      const passwordMap = {
        patient: 'patient123',
        staff: 'staff123',
        admin: 'admin123'
      };

      const emailInput = document.getElementById('loginEmail');
      const passwordInput = document.getElementById('loginPassword');
      if (emailInput && passwordInput) {
        emailInput.value = emailMap[role] || '';
        passwordInput.value = passwordMap[role] || '';
      }
    });
  });
});
